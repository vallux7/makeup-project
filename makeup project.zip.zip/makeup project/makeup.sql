-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 27, 2019 at 10:18 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `makeup`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `username` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL,
  `brand` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `quantity` int(10) NOT NULL,
  `price` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(3) NOT NULL,
  `image` varchar(50) NOT NULL,
  `brand` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `price` int(4) NOT NULL,
  `stock` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `image`, `brand`, `name`, `price`, `stock`) VALUES
(1, 'THEYRE REAL LINER MINI', 'Benefit', 'THEY\'RE REAL LINER MINI', 63, 7),
(2, 'لب كدل - براون سكر', 'Wow', 'Cdl Pulp - Brown Sugar', 35, 5),
(3, 'معزز إشراقة البشرة HIGHLIGHTER LIQUID HIGH BEAM', 'Benefit', ' HIGHLIGHTER LIQUID HIGH BEAM', 136, 3),
(4, 'البودرة السائبة ULTRA HD', 'Makeup forever', 'اULTRA HD', 175, 2),
(5, 'جل لزيادة كثافة الحواجب', 'Benefit', 'GIMME BROW MED/DEEP', 152, 8),
(6, 'BACKSTAGE PROS - DIOR ADDICT LIP GLOW 001', 'Dior', 'BACKSTAGE PROS - DIOR ADDICT LIP GLOW 001', 170, 10),
(7, 'RADIANT PRIMER CARAMEL 30ML', 'Makeup forever', 'RADIANT PRIMER CARAMEL 30ML', 165, 4),
(8, 'MASCARA VOLUME EFFET FAUX CILS THE SHOCK - BLACK', 'San lorean', 'MASCARA VOLUME EFFET FAUX CILS THE SHOCK - BLACK', 158, 11),
(9, 'دوبل تربل', 'Wow', 'double triple', 95, 13),
(10, 'روج إكلا  أحمر الشفاه ROUGE ECLAT 06', 'Klarns', ' ROUGE ECLAT 06', 128, 8);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `location` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `password`, `email`, `phone`, `location`) VALUES
('adn', '123434332', 'raul.2010@live.com', '0543238993', 'riyadh'),
('ali', '12345678', 'ali@hotmail.com', '0553238993', 'riyadh'),
('maha', '1234512345', 'maha@hotmail.com', '0543238993', 'riyadh');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

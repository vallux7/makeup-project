<!DOCTYPE html>
<html>
   <head>
      <meta charset = "utf-8">
      <title>Makeup</title>
	    <link rel = "stylesheet" type = "text/css" 
         href = "style.css">
	
   </head>
	
	<header>
		
	<div id="header_div">
		<br />
       <div>
  <h1 ><img id="logo" src="image/logo.png" alt="logo" />&nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp;&nbsp; &nbsp; My Makeup</h1>    
		   </div>
		
		<div>
<ul id="navlist">
            <li><a href="home.html" >Home</a></li>
		    <li><a href="makeup.php" >Makeup</a></li>
		     <li><a href="cart.php" >Shopping cart</a></li>
             <li><a href="faq.html" >FAQ</a></li>
             <li><a href="contact.html" >Contact us</a></li>
		    <li><a href="index.html" >Log out</a></li>
			</ul>
			</div>
		
		</div>
	</header>
	
   <body> 
	   
	   
 <div id="productList" class ="productList">
      <?php 
    $query = "SELECT * FROM `product`";            
   $database = mysqli_connect( "localhost","root","","makeup")	or die( "Could not connect to database" );
     mysqli_set_charset($database,'utf8');
   $result = mysqli_query($database, $query) ;
     
      while($row = mysqli_fetch_assoc($result )){
          ?>  
<a href="makeup_details.php?id=<?php echo $row['id']?>" style="color:inherit;">    
<div id="product" class="floating-box"  >
		<img src="image/<?php echo $row['image']?>.jpg" alt="image" style="width:200px;height:200px;" id="image" >
    	<label class="image/" id ="Brand"><?php echo $row['brand']?></label>
	     <br>
         <label id ="name"><?php echo $row['name']?></label>	
         <br>	
	     <label id ="price"><?php echo $row['price']?></label>
		</div>
     </a> 
     <?php
      }
          ?>
		
		</div>
		
	   <br><br><br><br><br>

    </body>
	

	
	</html>
<!DOCTYPE html>
<html>
   <head>
      <meta charset = "utf-8">
      <title>Contact us</title>
	    <link rel = "stylesheet" type = "text/css" 
         href = "style.css">
	
   </head>
	
	<header>
		
	<div id="header_div">
		<br />
       <div>
  <h1 ><img id="logo" src="image/logo.png" alt="logo" />&nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp;&nbsp; &nbsp; Admin</h1>    
		   </div>
		
		<div>
<ul id="navlist">
    <center>
            <li><a href="index.html" >Logout</a></li>
        </center>
            </ul>
        </div>
		
		</div>
	</header>
	
   <body> 

       
<div id="wrapper">
  <div id="left">
     <table>

<caption>Users</caption>

<thead>
<tr>
<th>Username</th>
<th>Password</th>
<th>Email</th> 
<th>Phone</th>  
<th>Location</th> 
<th>Action</th>       
</tr>
</thead>

<tbody>
 <?php 
    $query = "SELECT * FROM `user`";            
   $database = mysqli_connect( "localhost","root","","makeup")	or die( "Could not connect to database" );
     mysqli_set_charset($database,'utf8');
   $result = mysqli_query($database, $query) ;
     
      while($row = mysqli_fetch_assoc($result )){
          ?>      
<tr>
<td><?php echo $row['username']?></td>
<td><?php echo $row['password']?></td>
<td><?php echo $row['email']?></td>
<td><?php echo $row['phone']?></td>
<td><?php echo $row['location']?></td>
<td><a href="delete.php?username=<?php echo $row['username']?>">Delete</a></td>       
</tr>
    <?php
      } ?>
    
</tbody>
       </table>
 
    </div>
  <div id="right">
    <center>
    	<div >
	   <form id="form"  method = "post" action = "add_user.php">
	   <h2>Add new user</h2>				
      <p><input  class="input_add" name="username" type="text" placeholder="Username" required></p> 
       <P><input  class="input_add" name="password" type="password"  placeholder="Password" required></P>
	   <p><input  class="input_add" name="email" type="email" placeholder="Email" required></p>  
		<p><input  class="input_add" name="phone" type="tel" placeholder="Phone" required></p>     
	  <p><input  class="input_add" name="location" type="text" placeholder="Location" required></p>  
		   <P ><input id="button"  type="submit" value="Add"></P>
         <P class="lable_form" ><label></label></P>		 
	   </form>

				</div>  
        
                <br>
       <center>

         </center>
	   </center>
    </div>
</div>
      
       
       <br><br><br><br>
    </body>

	
	</html>
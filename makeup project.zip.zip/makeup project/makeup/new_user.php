<?php 

extract( $_POST );  

   
	 $query = "INSERT INTO `user`VALUES ('$username','$password','$email','$phone','$location')";
	  

       $database = mysqli_connect( "localhost","root","","makeup")	or die( "Could not connect to database" );
		mysqli_set_charset($database,'utf8');

       $result = mysqli_query($database, $query) ;
       if($result) 
	  echo  "Register compleate you can login";

    else
	  echo "Username register before ";

?>
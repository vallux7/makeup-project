<!DOCTYPE html>
<html>
   <head>
      <meta charset = "utf-8">
      <title>Makeup details</title>
	    <link rel = "stylesheet" type = "text/css" 
         href = "style.css">
	
   </head>
	
	<header>
		
	<div id="header_div">
		<br />
       <div>
  <h1 ><img id="logo" src="image/logo.png" alt="logo" />&nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp;&nbsp; &nbsp; My Style</h1>    
		   </div>
		
		<div>
<ul id="navlist">
            <li><a href="home.html" >Home</a></li>
		    <li><a href="makeup.php" >Makeup</a></li>
		     <li><a href="cart.php" >Shopping cart</a></li>
             <li><a href="faq.html" >FAQ</a></li>
             <li><a href="contact.html" >Contact us</a></li>
		    <li><a href="index.html" >Log out</a></li>
			</ul>
			</div>
		
		</div>
	</header>
	
   <body> 
     <?php 
         extract( $_REQUEST );
         settype($id,"integer");
         $query = "SELECT  * FROM `product` where id=$id";
         $database = mysqli_connect( "localhost","root","","makeup")	or die( "Could not connect to database" );
         mysqli_set_charset($database,'utf8');
         $result = mysqli_query($database, $query) ;
          $row = mysqli_fetch_assoc($result);
    ?>
       

<div id="div_details"  >
	
<form method="post" action="add_cart.php"> 
    
<img id="image_details" src="image/<?php echo $row['image']?>.jpg" width="200px" height="200px">
<input name="image" value='<?php echo $row['image']?>' hidden/>
<div id="div_info" >	
<br>
 <p>
<Label class="details_label"
	   id="brand" >Brand: <?php echo $row['brand']?></Label>
     
<input name="brand" value='<?php echo $row['brand']?>' hidden/>
     
</p>			
			
 <p>
<Label class="details_label"
	   id="name" name="name">Name: <?php echo $row['name']?></Label>	
<input name="name" value='<?php echo $row['name']?>' hidden/>     
</p>	
			

 <p>
<Label class="details_label"
	   id="price" name="price">Price: <?php echo $row['price']?></Label>
<input name="price" value=' <?php echo $row['price']?>' hidden/>      
</p>	
	
 <p>
<Label class="details_label"
	   id="stock" name="stock" >Stock:  <?php echo $row['stock']?></Label>	
  <input name="stock" value='<?php echo $row['stock']?>' hidden/>      
</p>			
		
		

<p>
<label class="details_label">Quantity :	
<input id="quantity" name="quantity" type=number  min = "1"
                  max = "100"
                  step = "1"
                  value = "1"	              
	   />
	</label>
	
</p>
	
<p>
		<button  id="addCart" type="submit">Add to cart</button>
	
    </p>
    
</div>
    </form>
    </div>
    

	 <br>  <br><br><br><br>
	   

    </body>


	</html>
<?php 

extract( $_REQUEST ); 

	 $query = "delete from user where username='$username'";
	  
       $database = mysqli_connect( "localhost","root","","makeup")	or die( "Could not connect to database" );
		mysqli_set_charset($database,'utf8');

       $result = mysqli_query($database, $query) ;
        header('location: users.php')
      
?>
<?php
       extract( $_POST );  

      if($username == 'admin' && $password=='1234'){
          header('Location: users.php');
      }

	 $query = "SELECT  `username`, `password` FROM `user` WHERE username = '$username' && password ='$password'";
	  
       $database = mysqli_connect( "localhost","root","","makeup")	or die( "Could not connect to database" );
        mysqli_set_charset($database,'utf8');			

       $result = mysqli_query($database, $query) ;
  
    if($result->num_rows === 0)
        echo "Username or password not correct";
    else{     
session_start();
$_SESSION['loged']= $username;		
header( 'Location: home.html' );
		
}
      
?>
<?php 

extract( $_POST ); 

session_start();
$username = $_SESSION['loged'];
settype($price,"integer");
settype($stock,"integer");
settype($quantity,"integer");
$totalPrice = $price * $quantity;

        if($quantity > $stock){
           echo 'Stock not enough'; 
        }
      else{
	 $query = "INSERT INTO `cart`VALUES ('$username','$image','$brand','$name',$quantity,$totalPrice)";
	  
       $database = mysqli_connect( "localhost","root","","makeup")	or die( "Could not connect to database" );
		mysqli_set_charset($database,'utf8');

       $result = mysqli_query($database, $query) ;
       echo "Add to cart successfully";
      }
?>
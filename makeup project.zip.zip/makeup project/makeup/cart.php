<!DOCTYPE html>
<html>
   <head>
      <meta charset = "utf-8">
      <title>Shopping cart</title>
	    <link rel = "stylesheet" type = "text/css" 
         href = "style.css">
	
   </head>
	
	<header>
		
	<div id="header_div">
		<br />
       <div>
  <h1 ><img id="logo" src="image/logo.png" alt="logo" />&nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp;&nbsp; &nbsp; My Makeup</h1>    
		   </div>
		
		<div>
<ul id="navlist">
            <li><a href="home.html" >Home</a></li>
		    <li><a href="makeup.php" >Makeup</a></li>
		     <li><a href="cart.php" >Shopping cart</a></li>
             <li><a href="faq.html" >FAQ</a></li>
             <li><a href="contact.html" >Contact us</a></li>
		    <li><a href="index.html" >Log out</a></li>
			</ul>
			</div>
		
		</div>
	</header>
	
   <body> 

	<div id="cartList" class="shopping-cart">   

<div  id="p" class="p">
	  
	 <ul id="cart_ull">

		<li > <label>Product Image</label>
			</li>
 <li >
<label >Brand</label> </li>
 <li >		 
<label >Name</label>	
	 </li>
		<li> 
<label >Quantity</label> </li>
		 <li> 
<label >Final price</label>		
			 </li>
	 </ul>
	  
  </div>
 		

	<hr>	
		
 <div id="product" class="product">
	  
     <?php
session_start();
$username = $_SESSION['loged'];
$query = "SELECT * FROM `cart` where username = '$username' ";
$database = mysqli_connect( "localhost","root","","makeup")	or die( "Could not connect to database" );
mysqli_set_charset($database,'utf8');
$result = mysqli_query($database, $query) ;

while($row = mysqli_fetch_assoc($result )){
    ?> 
	 <ul  id="cart_ul">

		<li > <img id="image_cart"  name="Dress" 
                   src="image/<?php echo $row['image']?>.jpg"   height="100"
	 width="130" alt="dress" />
			</li>
 <li >
 <?php echo $row['brand']?>
 <li >		 
<?php echo $row['name']?>	
	 </li>
		<li> 
 <?php echo $row['quantity']?></li>
		 <li> 
<?php echo $row['price']?> SR
			 </li>
	 </ul>
     
     <?php
}
     ?>
     
	<hr>  
  </div>
 	
    
    </div>
       <br><br>  <br><br>
       <center>
        <button onclick="location.href='payment.html'" id="button">Checkout</button>
         </center>
	
    </body>

	</html>